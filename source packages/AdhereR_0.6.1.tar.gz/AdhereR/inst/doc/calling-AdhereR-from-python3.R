## ---- echo=FALSE, message=FALSE, warning=FALSE, results='hide'----------------
# Various Rmarkdown output options:
# center figures and reduce their file size:
knitr::opts_chunk$set(fig.align = "center", dpi=100, dev="jpeg"); 

