# Julia wrapper

This folder contains the `Julia` module `adherer.jl` that implementes the `Julia` wrapper for `AdhereR`.
